create definer = root@localhost view student_info as
select `test`.`student`.`Sno`                                                AS `Sno`,
       `test`.`student`.`Sname`                                              AS `Sname`,
       if((((substr(`test`.`student`.`Sid`, 17, 1) + 0) % 2) = 0), '女',
          '男')                                                               AS `IF((SUBSTRING(Sid, 17, 1) + 0) % 2 = 0, '女', '男')`,
       (substr(now(), 1, 4) - substr(`test`.`student`.`Sid`, 7, 4))          AS `SUBSTRING(now(),1,4)-(SUBSTRING(Sid,7,4))`,
       (select `test`.`faculty`.`Fname`
        from `test`.`faculty`
        where (`test`.`faculty`.`Fno` = `test`.`student`.`Sfaculty`))        AS `(select Fname from faculty where Fno=student.Sfaculty)`
from `test`.`student`;

