create definer = root@localhost trigger TT
    after insert
    on teacher
    for each row
    insert into teacheruser(Tno, Tpassword) select Tno,MD5(SUBSTRING(Tno,7,6)) from teacher where Tno=NEW.Tno;

