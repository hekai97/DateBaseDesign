create definer = root@localhost trigger TS
    after insert
    on student
    for each row
    insert into studentuser (Sno,Spassword) select Sno,MD5(SUBSTRING(Sid,13,6)) from student where Sno=NEW.Sno;

